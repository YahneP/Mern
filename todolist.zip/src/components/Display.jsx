import React from 'react';

const Display = ({taskArray, setTaskArray}) => {

    const checkedHandler = e => {
        e.preventDefault();
    }
    const deleteHandler = e => {
        e.preventDefault();
        const filterTaskArray = taskArray.filter( tasks => tasks.id !== e.target.id)
        setTaskArray(filterTaskArray);
    }
    return (
        <ul>
            <h3>Todo List</h3>
            {
                taskArray.map( (tasks) => {
                    return(
                        <li key={tasks.id}>{tasks.taskItem}  <input type="checkbox" checked={tasks.isCompleted} onChange={checkedHandler}/>
                        <button onClick={deleteHandler}>Delete</button>
                        </li>
                    )
                })                
            }
        </ul>
    );
}

export default Display