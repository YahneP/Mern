import React, { useState } from 'react';

const Form = ({taskArray, setTaskArray}) => {

    const [taskItem, setTaskItem] = useState('');
    


    const newTaskHandler = (e) => {
        e.preventDefault();
        const newTaskItem = {
            id: Math.floor(Math.random() * 10000),
            taskItem,
            isCompleted: false
        }
        console.log(newTaskItem)
        const updatedTaskArray = [...taskArray, newTaskItem];
        setTaskArray(updatedTaskArray)
        setTaskItem("");
    }
    
    return (

            <form onSubmit={newTaskHandler}>
                <div>
                    <input type="text" value={taskItem} onChange={(e) => setTaskItem(e.target.value)} /> 
                </div>
                <button>Add</button>
            
            </form>
    
)}

export default Form