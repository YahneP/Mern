import React, {useState} from 'react';

const Counter= (props) => {

    const[count, setCount] = useState(0);

    const increaseCount = () => {
        setCount(count+1)
    }
    
    return(
        <div>
            <h2>Name: {props.Name}</h2>
            <h2>Age: {props.Age}</h2>
            <h2>Hair Color: {props.HairColor}</h2>
            <h2>The count is: {count}</h2>
            <button onClick={increaseCount}>Incerase count</button>
        </div>
)}

export default Counter;