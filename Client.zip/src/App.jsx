
import './App.css'
import Counter from './components/Counter'

function App() {
  return(
    <>
      <div>
        <div>
          <p>Hello world</p>
          <Counter Name="Jane Doe" Age={45} HairColor= "Brown"/>
        </div>
      </div>
    </>
  )}

export default App
